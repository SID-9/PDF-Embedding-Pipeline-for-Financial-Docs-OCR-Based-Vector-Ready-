# app.py

import streamlit as st
import requests

# Backend FastAPI endpoint
backend_url = "http://localhost:8000"  # Change if hosted remotely

# Streamlit UI Setup
st.set_page_config(page_title="📊 Financial Report QA Bot", layout="wide")
st.title("💬 AI Financial Report Assistant")

st.markdown("""
Welcome to the AI-powered **Financial Report Assistant**!  
Ask any question about the company's financial performance.  
Answers are derived from quarterly PDF reports using **OCR**, **semantic embeddings**, and **Groq's LLaMA 3**.
""")

# === User Input ===
question = st.text_input("🔍 Enter your financial question:")

top_k = st.slider("📚 How many document chunks should the LLM consider?", min_value=1, max_value=10, value=5)

if st.button("🔎 Get Answer"):
    if not question.strip():
        st.warning("❗ Please enter a question first.")
    else:
        with st.spinner("🤖 Thinking..."):
            try:
                response = requests.post(
                    f"{backend_url}/ask-gpt",
                    json={"question": question, "top_k": top_k},
                    timeout=60
                )

                if response.status_code == 200:
                    data = response.json()
                    st.success("✅ Answer:")
                    st.markdown(data["answer"])

                    st.markdown("### 📄 Source Chunks Used:")
                    for i, source in enumerate(data["sources"], 1):
                        chunk = source["chunk"]
                        metadata = source["metadata"]
                        st.markdown(f"**Chunk {i}:**\n{chunk}\n")
                        st.markdown(f"**Metadata:** {metadata}\n---")
                else:
                    st.error(f"❌ API Error {response.status_code}: {response.text}")

            except requests.exceptions.RequestException as e:
                st.error(f"⚠️ Request failed: {e}")
