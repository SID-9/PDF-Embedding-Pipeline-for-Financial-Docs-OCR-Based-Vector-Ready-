# main.py

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import faiss
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
import httpx
import os

# Set this via environment variable ideally
GROQ_API_KEY = os.getenv("GROQ_API_KEY") or "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"
GROQ_MODEL_NAME = "llama3-8b-8192"

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load FAISS and metadata
print("[⏳] Loading FAISS index and metadata...")
index = faiss.read_index("D:/fast api learning/financial-chatbot/data/financial_faiss.index")
df = pd.read_pickle("D:/fast api learning/financial-chatbot/data/processed_texts.pkl")
texts = df["formatted_text"].tolist()
metadata = df["metadata"].tolist()

# Use updated embedding model
model = SentenceTransformer("BAAI/bge-base-en")
print("[✔] BGE model loaded. Ready to answer!")

# Pydantic request model
class QuestionInput(BaseModel):
    question: str
    top_k: int = 5

# Function to query Groq LLM
async def query_groq_llm(prompt: str, model: str = GROQ_MODEL_NAME) -> str:
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": model,
        "messages": [
            {"role": "system", "content": "You are a helpful financial analyst AI assistant."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 400
    }

    async with httpx.AsyncClient() as client:
        response = await client.post(url, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()
        return result["choices"][0]["message"]["content"].strip()

# Main endpoint
@app.post("/ask-gpt",status_code=status.HTTP_200_OK)
async def ask_question(data: QuestionInput):
    try:
        q_embed = model.encode([data.question], normalize_embeddings=True).astype("float32")
        _, indices = index.search(q_embed, data.top_k)

        matches = [texts[i] for i in indices[0]]
        matched_meta = [metadata[i] for i in indices[0]]

        context = "\n\n".join(matches)
        prompt = f"""
Based on the financial context below, answer the following question in a clear, accurate, and concise manner.

Context:
{context}

Question:
{data.question}

Answer:
        """

        answer = await query_groq_llm(prompt)
        return {
            "answer": answer,
            "sources": [
                {"chunk": matches[i], "metadata": matched_meta[i]} for i in range(len(matches))
            ]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
