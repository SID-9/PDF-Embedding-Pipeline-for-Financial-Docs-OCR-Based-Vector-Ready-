import os
import fitz  # PyMuPDF
import pytesseract  # Tesseract OCR
from PIL import Image
import pandas as pd
from io import BytesIO


# Explicitly provide full path to tesseract.exe
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


# Function to extract images from PDFs
def extract_images(pdf_path):
    doc = fitz.open(pdf_path)
    images = []
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        img_list = page.get_images(full=True)
        for img_index, img in enumerate(img_list):
            xref = img[0]
            base_image = doc.extract_image(xref)
            img_bytes = base_image["image"]
            img = Image.open(BytesIO(img_bytes))
            images.append({
                "page": page_num + 1,
                "image": img
            })
    return images

# Function to extract text and OCR text from images
def extract_text_and_images(pdf_dir="D:/fast api learning/financial-chatbot/data/pdfs/"):
    data = []
    
    for fname in os.listdir(pdf_dir):
        if fname.endswith(".pdf"):
            path = os.path.join(pdf_dir, fname)
            print(f"Processing: {fname}")
            doc = fitz.open(path)

            # Extract text
            for page_num, page in enumerate(doc):
                text = page.get_text()
                if text.strip():  # skip blank pages
                    data.append({
                        "filename": fname,
                        "page": page_num + 1,
                        "text_type": "paragraph",
                        "text": text.strip()
                    })

            # Extract images and process with OCR
            images = extract_images(path)
            for img in images:
                # Run OCR on each image
                ocr_text = pytesseract.image_to_string(img["image"])  # OCR for image text extraction
                if ocr_text.strip():  # only append if OCR returns non-empty text
                    data.append({
                        "filename": fname,
                        "page": img["page"],
                        "text_type": "image_ocr",
                        "text": ocr_text.strip()
                    })

            doc.close()

    # Convert the collected data into a DataFrame and save to pickle
    df = pd.DataFrame(data)
    df.to_pickle("D:/fast api learning/financial-chatbot/data/processed_texts.pkl")
    print(f"[✔] Extracted text and OCR text from images and saved to data/processed_texts.pkl")

if __name__ == "__main__":
    extract_text_and_images()
