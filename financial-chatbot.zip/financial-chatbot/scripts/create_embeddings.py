# scripts/create_embeddings.py

import faiss
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
import os

def create_faiss_index(
    pkl_path="D:/fast api learning/financial-chatbot/data/processed_texts.pkl",
    save_dir="D:/fast api learning/financial-chatbot/data/"
):
    # Load extracted text
    df = pd.read_pickle(pkl_path)

    # Add a metadata column (useful for source filtering/tracing)
    df["metadata"] = df.apply(
        lambda row: f"{row['filename'].replace('.pdf', '')}_Page{row['page']}", axis=1
    )

    # Create formatted text with metadata included
    df["formatted_text"] = df.apply(
        lambda row: f"{row['text_type']} from {row['filename']} (Page {row['page']}): {row['text']}",
        axis=1
    )

    texts = df["formatted_text"].tolist()

    # Load embedding model
    model = SentenceTransformer("BAAI/bge-base-en")
    print("[✔] BGE model loaded.")

    # Generate embeddings
    print("[⏳] Generating embeddings...")
    embeddings = model.encode(texts, normalize_embeddings=True)
    embeddings = np.array(embeddings).astype("float32")

    # Build FAISS index
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)

    # Save FAISS index and updated metadata
    os.makedirs(save_dir, exist_ok=True)
    faiss.write_index(index, os.path.join(save_dir, "financial_faiss.index"))
    df.to_pickle(os.path.join(save_dir, "processed_texts.pkl"))

    print(f"[✔] Saved updated FAISS index and metadata to {save_dir}")

if __name__ == "__main__":
    create_faiss_index()
